package com.prafull.ai.agent.tools

data class ToolResult(val success: Boolean, val spokenResponse: String)

/**
 * Every capability the agent can invoke implements Tool. The planner never
 * executes arbitrary code — it can only select among these registered,
 * permission-checked tools. This is the enforcement point for section 9/24
 * of the spec (no unrestricted command execution).
 */
interface Tool {
    val name: String
    /** Return false if a required Android permission is missing; the caller
     *  is responsible for prompting for it rather than silently failing. */
    fun hasRequiredPermission(): Boolean
    suspend fun execute(args: Map<String, String>): ToolResult
}
