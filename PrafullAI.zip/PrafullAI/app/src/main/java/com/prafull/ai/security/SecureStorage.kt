package com.prafull.ai.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Wraps EncryptedSharedPreferences (backed by Android Keystore) for anything
 * sensitive: provider API keys, endpoints, and the selected TTS voice ID.
 *
 * Nothing stored here is ever written to Logcat, notifications, or voice output.
 * Keys are only ever read into memory right before an HTTP call and never
 * echoed back in error messages (see ai/providers/*Provider.kt).
 */
class SecureStorage(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "prafull_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun putString(key: String, value: String) = prefs.edit().putString(key, value).apply()
    fun getString(key: String, default: String? = null): String? = prefs.getString(key, default)
    fun remove(key: String) = prefs.edit().remove(key).apply()
    fun clearAll() = prefs.edit().clear().apply()
    fun contains(key: String) = prefs.contains(key)

    companion object {
        fun providerKeyAlias(providerId: String) = "provider_key_$providerId"
        fun providerEndpointAlias(providerId: String) = "provider_endpoint_$providerId"
        fun providerModelAlias(providerId: String) = "provider_model_$providerId"
        const val SELECTED_TTS_VOICE_ID = "selected_tts_voice_id"
        const val SELECTED_TTS_LOCALE = "selected_tts_locale"
        const val SPEECH_RATE = "speech_rate"
        const val SPEECH_VOLUME = "speech_volume"
        const val DEFAULT_PROVIDER_ID = "default_provider_id"
    }
}
