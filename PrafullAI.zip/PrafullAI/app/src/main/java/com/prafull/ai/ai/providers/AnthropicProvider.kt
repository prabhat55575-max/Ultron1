package com.prafull.ai.ai.providers

import com.prafull.ai.ai.AICapability
import com.prafull.ai.ai.AIProvider
import com.prafull.ai.ai.AIProviderConfig
import com.prafull.ai.ai.AIResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Adapter for the Anthropic Messages API. Implemented per Anthropic's official
 * docs (x-api-key header + anthropic-version header, distinct from OpenAI's
 * Authorization: Bearer scheme) — the two are NOT interchangeable.
 */
class AnthropicProvider(override val config: AIProviderConfig) : AIProvider {

    private val client = OkHttpClient()

    override suspend fun testConnection(apiKey: String): AIResult =
        sendPrompt(apiKey, "You are a connection test.", "Reply with OK.")

    override suspend fun sendPrompt(
        apiKey: String,
        systemPrompt: String,
        userMessage: String,
        capability: AICapability
    ): AIResult = withContext(Dispatchers.IO) {
        if (capability !in config.capabilities) {
            return@withContext AIResult(
                success = false,
                errorMessage = "${config.displayName} / ${config.model} does not support $capability."
            )
        }
        try {
            val body = JSONObject().apply {
                put("model", config.model)
                put("max_tokens", 1024)
                put("system", systemPrompt)
                put("messages", JSONArray().apply {
                    put(JSONObject().put("role", "user").put("content", userMessage))
                })
            }
            val request = Request.Builder()
                .url(config.endpoint) // e.g. https://api.anthropic.com/v1/messages
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext AIResult(
                        success = false,
                        errorMessage = "Anthropic request failed (HTTP ${response.code})."
                    )
                }
                val json = JSONObject(raw)
                val text = json.getJSONArray("content").getJSONObject(0).getString("text")
                AIResult(success = true, text = text)
            }
        } catch (e: Exception) {
            AIResult(success = false, errorMessage = "Network or parsing error: ${e.message}")
        }
    }
}
