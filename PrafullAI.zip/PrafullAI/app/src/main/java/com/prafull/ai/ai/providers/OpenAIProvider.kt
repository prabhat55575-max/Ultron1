package com.prafull.ai.ai.providers

import com.prafull.ai.ai.AICapability
import com.prafull.ai.ai.AIProvider
import com.prafull.ai.ai.AIProviderConfig
import com.prafull.ai.ai.AIResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class OpenAIProvider(override val config: AIProviderConfig) : AIProvider {

    private val client = OkHttpClient()

    override suspend fun testConnection(apiKey: String): AIResult =
        sendPrompt(apiKey, "You are a connection test.", "Reply with OK.")

    override suspend fun sendPrompt(
        apiKey: String,
        systemPrompt: String,
        userMessage: String,
        capability: AICapability
    ): AIResult = withContext(Dispatchers.IO) {
        if (capability !in config.capabilities) {
            return@withContext AIResult(
                success = false,
                errorMessage = "${config.displayName} / ${config.model} does not support $capability."
            )
        }
        try {
            val body = JSONObject().apply {
                put("model", config.model)
                put("messages", JSONArray().apply {
                    put(JSONObject().put("role", "system").put("content", systemPrompt))
                    put(JSONObject().put("role", "user").put("content", userMessage))
                })
            }
            val request = Request.Builder()
                .url(config.endpoint) // e.g. https://api.openai.com/v1/chat/completions
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    // Never echo the API key; only status + provider-supplied message.
                    return@withContext AIResult(
                        success = false,
                        errorMessage = "OpenAI request failed (HTTP ${response.code})."
                    )
                }
                val json = JSONObject(raw)
                val text = json.getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                AIResult(success = true, text = text)
            }
        } catch (e: Exception) {
            AIResult(success = false, errorMessage = "Network or parsing error: ${e.message}")
        }
    }
}
