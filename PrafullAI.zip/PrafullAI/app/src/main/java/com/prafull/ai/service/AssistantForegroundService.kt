package com.prafull.ai.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.prafull.ai.MainActivity
import com.prafull.ai.OwnerProfile
import com.prafull.ai.PrafullApplication.Companion.CHANNEL_ID
import com.prafull.ai.security.SecureStorage
import com.prafull.ai.voice.SpeechToText
import com.prafull.ai.voice.TextToSpeechManager
import com.prafull.ai.wakeword.WakeWordDetector

/**
 * Legitimate Android foreground service — visible notification, explicit
 * ON/OFF control from the main screen, no hidden recording. Runs the wake-word
 * loop and hands off to the agent pipeline once "Hey Prafull AI" is heard.
 */
class AssistantForegroundService : Service() {

    private lateinit var tts: TextToSpeechManager
    private lateinit var stt: SpeechToText
    private lateinit var wakeWordDetector: WakeWordDetector

    override fun onCreate() {
        super.onCreate()
        val storage = SecureStorage(applicationContext)
        stt = SpeechToText(applicationContext)
        tts = TextToSpeechManager(applicationContext, storage)
        wakeWordDetector = WakeWordDetector(applicationContext, stt)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                wakeWordDetector.stop()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForeground(NOTIFICATION_ID, buildNotification())
                tts.init {
                    wakeWordDetector.listen(
                        onWake = {
                            tts.speak(OwnerProfile.GREETING)
                            // Hand off to the AI planner / agent pipeline here (see agent package).
                        },
                        onListeningError = { /* surface to UI state / log locally only */ }
                    )
                }
            }
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Prafull AI is listening")
            .setContentText("Say \"Hey Prafull AI\" to give a command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        wakeWordDetector.stop()
        tts.shutdown()
        stt.destroy()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    companion object {
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.prafull.ai.action.STOP"
    }
}
