package com.prafull.ai.agent.tools

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Uses YouTube's public intent/deep-link surface only — no scraping, no
 * bypassing auth. If a specific action (e.g. opening an exact video by
 * spoken title) can't be resolved to a safe deep link, it falls back to a
 * search intent and lets the user pick, per spec section 11.
 */
class YouTubeTool(private val context: Context) : Tool {
    override val name = "youtube"
    override fun hasRequiredPermission() = true

    override suspend fun execute(args: Map<String, String>): ToolResult {
        val query = args["query"]
        val intent = if (query.isNullOrBlank()) {
            context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
        } else {
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}"))
        } ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            ToolResult(true, if (query.isNullOrBlank()) "Opening YouTube." else "YouTube par \"$query\" search kar raha hoon.")
        } catch (e: Exception) {
            ToolResult(false, "Prafull, YouTube open nahi ho paya.")
        }
    }
}
