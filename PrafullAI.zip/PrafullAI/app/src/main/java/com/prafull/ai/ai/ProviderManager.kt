package com.prafull.ai.ai

import com.prafull.ai.ai.providers.AnthropicProvider
import com.prafull.ai.ai.providers.OpenAIProvider
import com.prafull.ai.security.SecureStorage

/**
 * Holds configured providers, resolves the default / task-specific provider,
 * and supports an optional primary -> secondary -> tertiary fallback chain.
 * Google, xAI, OpenRouter, Luma, and Custom API adapters follow the same
 * AIProvider interface — add their classes to `build()` the same way as
 * OpenAIProvider / AnthropicProvider once you have API docs + a key to test.
 */
class ProviderManager(private val storage: SecureStorage) {

    private val configs = mutableMapOf<String, AIProviderConfig>()
    private val taskOverrides = mutableMapOf<String, String>() // taskType -> providerId

    fun registerProvider(config: AIProviderConfig, apiKey: String) {
        configs[config.id] = config
        storage.putString(SecureStorage.providerKeyAlias(config.id), apiKey)
        storage.putString(SecureStorage.providerEndpointAlias(config.id), config.endpoint)
        storage.putString(SecureStorage.providerModelAlias(config.id), config.model)
    }

    fun removeProvider(providerId: String) {
        configs.remove(providerId)
        storage.remove(SecureStorage.providerKeyAlias(providerId))
        storage.remove(SecureStorage.providerEndpointAlias(providerId))
        storage.remove(SecureStorage.providerModelAlias(providerId))
    }

    fun setDefault(providerId: String) = storage.putString(SecureStorage.DEFAULT_PROVIDER_ID, providerId)

    fun setTaskProvider(taskType: String, providerId: String) { taskOverrides[taskType] = providerId }

    fun resolve(taskType: String? = null): AIProvider? {
        val id = taskType?.let { taskOverrides[it] }
            ?: storage.getString(SecureStorage.DEFAULT_PROVIDER_ID)
            ?: return null
        val cfg = configs[id] ?: return null
        return build(cfg)
    }

    fun apiKeyFor(providerId: String): String? = storage.getString(SecureStorage.providerKeyAlias(providerId))

    private fun build(config: AIProviderConfig): AIProvider = when {
        config.id.startsWith("openai") -> OpenAIProvider(config)
        config.id.startsWith("anthropic") -> AnthropicProvider(config)
        // TODO V1.x: GoogleProvider, XAIProvider, OpenRouterProvider, LumaProvider, CustomApiProvider
        else -> OpenAIProvider(config) // generic OpenAI-compatible fallback for custom endpoints
    }
}
