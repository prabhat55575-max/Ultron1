package com.prafull.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.prafull.ai.ui.PrafullAiApp
import com.prafull.ai.ui.theme.PrafullAITheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PrafullAITheme {
                PrafullAiApp()
            }
        }
    }
}
