package com.prafull.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.prafull.ai.security.SecureStorage
import java.util.Locale
import java.util.UUID

/**
 * Wraps Android TextToSpeech. Whatever voice the user selects in
 * Settings -> Voice is persisted to SecureStorage and re-applied on every
 * app/service restart and before every utterance — the engine's default
 * voice is never silently substituted.
 */
class TextToSpeechManager(
    private val context: Context,
    private val storage: SecureStorage
) {
    private var tts: TextToSpeech? = null
    private var ready = false
    var onUnavailableVoice: ((String) -> Unit)? = null

    fun init(onReady: () -> Unit) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                restoreSavedVoice()
                onReady()
            }
        }
    }

    fun availableVoices(): List<Voice> = tts?.voices?.toList().orEmpty()

    fun selectVoice(voice: Voice) {
        tts?.voice = voice
        storage.putString(SecureStorage.SELECTED_TTS_VOICE_ID, voice.name)
        storage.putString(SecureStorage.SELECTED_TTS_LOCALE, voice.locale.toLanguageTag())
    }

    fun setRate(rate: Float) {
        tts?.setSpeechRate(rate)
        storage.putString(SecureStorage.SPEECH_RATE, rate.toString())
    }

    fun setVolumeHint(volume: Float) {
        // Actual playback volume is applied via the AudioManager stream at speak() time.
        storage.putString(SecureStorage.SPEECH_VOLUME, volume.toString())
    }

    private fun restoreSavedVoice() {
        val savedId = storage.getString(SecureStorage.SELECTED_TTS_VOICE_ID) ?: return
        val match = tts?.voices?.firstOrNull { it.name == savedId }
        if (match != null) {
            tts?.voice = match
        } else {
            onUnavailableVoice?.invoke(savedId)
        }
        storage.getString(SecureStorage.SPEECH_RATE)?.toFloatOrNull()?.let { tts?.setSpeechRate(it) }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!ready) return
        val utteranceId = UUID.randomUUID().toString()
        onDone?.let { cb ->
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) = cb()
                override fun onError(utteranceId: String?) {}
            })
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() = tts?.stop()

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
