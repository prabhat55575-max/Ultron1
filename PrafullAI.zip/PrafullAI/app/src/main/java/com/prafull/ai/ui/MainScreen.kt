package com.prafull.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prafull.ai.OwnerProfile

@Composable
fun PrafullAiApp() {
    var assistantActive by remember { mutableStateOf(false) }
    var lastCommand by remember { mutableStateOf("—") }
    var providerStatus by remember { mutableStateOf("Not configured") }
    var selectedVoiceLabel by remember { mutableStateOf("Default") }
    var currentScreen by remember { mutableStateOf(Screen.Home) }

    when (currentScreen) {
        Screen.Home -> HomeScreen(
            assistantActive = assistantActive,
            onToggleAssistant = { assistantActive = !assistantActive },
            lastCommand = lastCommand,
            providerStatus = providerStatus,
            selectedVoiceLabel = selectedVoiceLabel,
            onNavigate = { currentScreen = it }
        )
        else -> PlaceholderScreen(currentScreen) { currentScreen = Screen.Home }
    }
}

enum class Screen { Home, AIProviders, Voice, Permissions, Memory, History, Settings }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(
    assistantActive: Boolean,
    onToggleAssistant: () -> Unit,
    lastCommand: String,
    providerStatus: String,
    selectedVoiceLabel: String,
    onNavigate: (Screen) -> Unit
) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                OwnerProfile.ASSISTANT_NAME.uppercase(),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(4.dp))
            StatusPill(active = assistantActive)

            Spacer(Modifier.height(40.dp))
            MicButton(active = assistantActive, onClick = onToggleAssistant)
            Spacer(Modifier.height(12.dp))
            Text("Hey Prafull AI", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))

            Spacer(Modifier.height(32.dp))
            InfoCard("Last Command", lastCommand)
            Spacer(Modifier.height(12.dp))
            InfoCard("AI Provider", providerStatus)
            Spacer(Modifier.height(12.dp))
            InfoCard("Voice", selectedVoiceLabel)

            Spacer(Modifier.height(32.dp))
            val menuItems = listOf(
                "AI Providers" to Screen.AIProviders,
                "Voice" to Screen.Voice,
                "Permissions" to Screen.Permissions,
                "Memory" to Screen.Memory,
                "History" to Screen.History,
                "Settings" to Screen.Settings
            )
            menuItems.forEach { (label, screen) ->
                OutlinedButton(
                    onClick = { onNavigate(screen) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) { Text(label) }
            }
        }
    }
}

@Composable
private fun StatusPill(active: Boolean) {
    val label = if (active) "● ASSISTANT ACTIVE" else "○ ASSISTANT OFF"
    val color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
    Text(label, color = color, fontSize = 13.sp)
}

@Composable
private fun MicButton(active: Boolean, onClick: () -> Unit) {
    val bg = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
    Box(
        modifier = Modifier
            .size(96.dp)
            .clip(CircleShape)
            .background(bg)
            .clickable(onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Filled.Mic,
            contentDescription = "Toggle assistant",
            tint = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
        )
    }
}

// small helper so MicButton reads cleanly above
private fun Modifier.clickable(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))

@Composable
private fun InfoCard(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            Text(value, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun PlaceholderScreen(screen: Screen, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("$screen screen", fontSize = 20.sp)
        Spacer(Modifier.height(16.dp))
        Text(
            "Build out per section of the spec (AI Providers form, Voice picker with preview, " +
                "permission wizard, Memory viewer, History list, Settings).",
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = onBack) { Text("Back") }
    }
}
