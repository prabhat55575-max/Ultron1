package com.prafull.ai.history

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(val command: String, val timeMillis: Long, val action: String, val result: String)

/** Local, user-clearable log of every voice command, resolved action, and result. */
class CommandHistory(context: Context) {
    private val prefs = context.getSharedPreferences("prafull_history", Context.MODE_PRIVATE)
    private val key = "entries_json"

    fun add(entry: HistoryEntry) {
        val arr = readArray()
        arr.put(JSONObject().apply {
            put("command", entry.command)
            put("time", entry.timeMillis)
            put("action", entry.action)
            put("result", entry.result)
        })
        prefs.edit().putString(key, arr.toString()).apply()
    }

    fun all(): List<HistoryEntry> {
        val arr = readArray()
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            HistoryEntry(o.getString("command"), o.getLong("time"), o.getString("action"), o.getString("result"))
        }.reversed()
    }

    fun clear() = prefs.edit().remove(key).apply()

    private fun readArray(): JSONArray {
        val raw = prefs.getString(key, null) ?: return JSONArray()
        return JSONArray(raw)
    }
}
