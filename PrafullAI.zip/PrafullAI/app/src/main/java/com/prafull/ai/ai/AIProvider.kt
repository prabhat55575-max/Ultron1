package com.prafull.ai.ai

/** Capabilities a provider/model may support. Used to reject unsupported requests
 *  instead of silently failing or falsely claiming a capability exists. */
enum class AICapability { TEXT, CODE, IMAGE, VIDEO }

data class AIProviderConfig(
    val id: String,
    val displayName: String,
    val endpoint: String,
    val model: String,
    val authType: AuthType = AuthType.BEARER,
    val capabilities: Set<AICapability> = setOf(AICapability.TEXT),
    val enabled: Boolean = true
)

enum class AuthType { BEARER, API_KEY_HEADER, QUERY_PARAM, X_API_KEY }

data class AIResult(
    val success: Boolean,
    val text: String? = null,
    val errorMessage: String? = null
)

/**
 * Every provider (OpenAI, Google, Anthropic, xAI, OpenRouter, Luma, or a
 * user-defined custom API) implements this. Each adapter knows its own
 * request/response shape — callers never assume a common wire format.
 */
interface AIProvider {
    val config: AIProviderConfig

    suspend fun testConnection(apiKey: String): AIResult

    suspend fun sendPrompt(
        apiKey: String,
        systemPrompt: String,
        userMessage: String,
        capability: AICapability = AICapability.TEXT
    ): AIResult
}
