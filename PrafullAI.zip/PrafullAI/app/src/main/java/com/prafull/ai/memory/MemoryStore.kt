package com.prafull.ai.memory

import android.content.Context

/**
 * Local-only key/value memory (owner name, selected voice, language, default
 * provider, preferences, learned common commands). Never synced anywhere.
 * Backed by plain SharedPreferences since none of this is a credential —
 * secrets (API keys, voice engine internals) live in SecureStorage instead.
 */
class MemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("prafull_memory", Context.MODE_PRIVATE)

    fun set(key: String, value: String) = prefs.edit().putString(key, value).apply()
    fun get(key: String): String? = prefs.getString(key, null)
    fun all(): Map<String, String> = prefs.all.mapNotNull { (k, v) -> (v as? String)?.let { k to it } }.toMap()
    fun delete(key: String) = prefs.edit().remove(key).apply()
    fun clearAll() = prefs.edit().clear().apply()
}
