package com.prafull.ai.wakeword

import android.content.Context
import com.prafull.ai.PrafullApplication.Companion
import com.prafull.ai.voice.SpeechToText

/**
 * V1 wake-word strategy: repeated short SpeechRecognizer sessions while the
 * foreground service is alive, checking each transcript for the wake phrase.
 *
 * LIMITATION (surfaced in Settings -> Background Assistant, not hidden):
 * - This only works while the foreground service is running and Android has
 *   not suspended it (Doze / OEM battery managers can still kill it).
 * - It is NOT a true low-power always-on hotword engine like the one used by
 *   "OK Google" — that requires a DSP/on-device wake-word model.
 * - For a production-grade always-listening experience, swap this class's
 *   implementation for an offline engine such as Picovoice Porcupine (has a
 *   free tier + Android SDK) trained on "Hey Prafull AI", and keep the same
 *   listen()/stop() contract so nothing else in the app needs to change.
 */
class WakeWordDetector(
    private val context: Context,
    private val stt: SpeechToText,
    private val wakePhrase: String = "hey prafull ai"
) {
    private var listening = false

    fun listen(onWake: () -> Unit, onListeningError: (String) -> Unit) {
        listening = true
        loop(onWake, onListeningError)
    }

    private fun loop(onWake: () -> Unit, onListeningError: (String) -> Unit) {
        if (!listening) return
        stt.startListening(
            onResult = { text ->
                if (text.lowercase().contains(wakePhrase)) {
                    onWake()
                }
                if (listening) loop(onWake, onListeningError)
            },
            onError = { err ->
                onListeningError(err)
                if (listening) loop(onWake, onListeningError)
            }
        )
    }

    fun stop() {
        listening = false
        stt.stop()
    }
}
