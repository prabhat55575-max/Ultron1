package com.prafull.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Original dark futuristic palette — deliberately not Iron Man red/gold.
private val PrafullDark = darkColorScheme(
    primary = Color(0xFF35E0C4),
    secondary = Color(0xFF6C63FF),
    tertiary = Color(0xFFB4A0FF),
    background = Color(0xFF0A0E14),
    surface = Color(0xFF12161F),
    onPrimary = Color(0xFF03110D),
    onBackground = Color(0xFFE4E9F2),
    onSurface = Color(0xFFE4E9F2)
)

@Composable
fun PrafullAITheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = PrafullDark, content = content)
}
