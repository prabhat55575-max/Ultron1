package com.prafull.ai.agent.tools

import android.content.Context
import android.content.Intent

class OpenAppTool(private val context: Context) : Tool {
    override val name = "open_app"
    override fun hasRequiredPermission() = true // launching apps via intents needs no runtime permission

    override suspend fun execute(args: Map<String, String>): ToolResult {
        val packageName = args["package"] ?: return ToolResult(false, "Prafull, kis app ko kholna hai, ye clear nahi hua.")
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            ToolResult(true, "Opening ${args["label"] ?: packageName}.")
        } else {
            ToolResult(false, "Prafull, ${args["label"] ?: packageName} installed nahi hai.")
        }
    }
}
