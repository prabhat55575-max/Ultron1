package com.prafull.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

/**
 * Owner profile is fixed for this build: assistant name "Prafull AI", owner "Prafull".
 * This is intentionally a constant, not user-editable, per the product spec.
 */
object OwnerProfile {
    const val ASSISTANT_NAME = "Prafull AI"
    const val OWNER_NAME = "Prafull"
    const val WAKE_PHRASE = "hey prafull ai"
    const val GREETING = "Yes sir, Prafull."
}

class PrafullApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Prafull AI Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows when Prafull AI is listening in the background"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "prafull_ai_assistant"
    }
}
