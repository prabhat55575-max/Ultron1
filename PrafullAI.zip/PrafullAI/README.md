# Prafull AI — V1

A voice-first Android assistant. Owner: **Prafull**. This build implements
**Phase V1** from the spec: app shell, encrypted API-key storage, one working
AI provider adapter (OpenAI) plus a second (Anthropic) to prove the interface
generalizes, voice selection with persistence, speech-to-text, text-to-speech,
wake-phrase detection, a foreground background service, and two basic tools
(open app, YouTube).

## Open in Android Studio
1. Open this folder as an existing project (Android Studio Koala+ / AGP 8.5).
2. Let Gradle sync — it will download the wrapper distribution on first run
   (requires network; this environment doesn't have one, so the project has
   **not** been compiled here — review the source and build locally).
3. Run on a device/emulator with API 26+.

## What's real vs. what's a seam for V2/V3
**Implemented and functional:**
- Encrypted API key storage (`security/SecureStorage.kt`, Android Keystore via `EncryptedSharedPreferences`)
- `AIProvider` interface + `OpenAIProvider` + `AnthropicProvider` adapters, each coded to that provider's actual wire format
- `ProviderManager` for default/task-specific provider + fallback chain scaffolding
- TTS voice selection that persists across restarts and never silently swaps (`voice/TextToSpeechManager.kt`)
- STT wrapper with locale switching for Hindi/English/Hinglish (`voice/SpeechToText.kt`)
- Foreground service with visible notification + explicit ON/OFF (`service/AssistantForegroundService.kt`)
- Local, user-clearable memory and command history stores
- `Tool` interface + `OpenAppTool` + `YouTubeTool` as the pattern for every other tool in the spec
- Compose UI matching the wireframe (status pill, mic button, provider/voice cards, nav menu)

**Deliberately stubbed / documented limitation:**
- **Wake word**: `wakeword/WakeWordDetector.kt` uses repeated short `SpeechRecognizer`
  sessions inside the foreground service. This is the "closest legitimate solution"
  per the spec, but it is *not* a true low-power always-on hotword engine — Android
  can still suspend it under Doze or aggressive OEM battery managers. The class
  is written so you can drop in Picovoice Porcupine (or Vosk) behind the same
  `listen()/stop()` contract without touching any caller.
- Google/xAI/OpenRouter/Luma/Custom-API provider adapters: same `AIProvider`
  interface, not yet implemented — add a class per provider once you have that
  provider's current API docs, same as `OpenAIProvider`/`AnthropicProvider`.
- Remaining V1 tools (Camera, WhatsApp, Google Maps, Contact, File, Clipboard,
  Volume, Settings, Accessibility, Coding, WebsiteBuilder) and the AI planner
  that turns a transcript into a tool call: not yet wired up — `Tool.kt` and the
  two example tools are the pattern to extend.
- Onboarding permission wizard, Settings → AI Providers form, Settings → Voice
  picker UI, Memory viewer, History list UI: `MainScreen.kt` has a placeholder
  screen per section; the underlying stores (`MemoryStore`, `CommandHistory`,
  `ProviderManager`) they'd bind to already exist.

## Security notes already in place
- API keys never appear in Logcat, error strings, or notifications — provider
  adapters return `HTTP <code>` on failure, never the request/response body.
- No `WAKE_LOCK`, no accessibility service enabled by default (it's commented
  out in the manifest until V3), no always-on recording — the mic only opens
  during an active recognition session inside the foreground service.

## Next step
Wire the AI planner (STT transcript → provider prompt → JSON tool call →
`ToolResult` → TTS) per the pipeline in spec section 9, then move to V2
(YouTube search/deep-link refinement, WhatsApp pre-fill, Maps business search,
Accessibility actions) only once V1 is tested end-to-end on a device.
